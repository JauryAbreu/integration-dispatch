﻿namespace integration_dispatch.Model
{
    public class WhereMapping
    {
        public string SourceKey { get; set; }
        public string DestinationKey { get; set; }
    }
}
