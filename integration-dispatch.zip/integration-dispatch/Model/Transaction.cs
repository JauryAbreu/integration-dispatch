﻿namespace integration_dispatch.Model
{
    public class Transaction
    {
        public Dictionary<string, object> Values { get; set; } = new();
    }
}
