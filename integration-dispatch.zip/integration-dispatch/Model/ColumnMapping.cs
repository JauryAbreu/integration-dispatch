﻿namespace integration_dispatch.Model
{
    public class ColumnMapping
    {
        public string SourceColumn { get; set; }
        public string DestinationColumn { get; set; }
    }
}
