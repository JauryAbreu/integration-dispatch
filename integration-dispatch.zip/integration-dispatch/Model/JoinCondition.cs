﻿namespace integration_dispatch.Model
{
    public class JoinCondition
    {
        public string SourceKey { get; set; }
        public string TargetKey { get; set; }
    }
}
