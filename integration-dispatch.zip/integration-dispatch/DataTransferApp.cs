using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using integration_dispatch.Model;
using Newtonsoft.Json;

namespace integration_dispatch
{
    public partial class DataTransferApp : Form
    {
        private Config config;
        private bool isRunning;

        public DataTransferApp()
        {
            InitializeComponent();
            LoadConfig();
        }

        private Button btnRun;
        private Label lblStatus;
        private DateTimePicker dtpStartDate;

        private void LoadConfig()
        {
            try
            {
                config = JsonConvert.DeserializeObject<Config>(File.ReadAllText("config.json"));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar la configuraci�n: {ex.Message}");
            }
        }

        private async void btnRun_Click(object sender, EventArgs e)
        {
            if (isRunning) return;

            isRunning = true;
            lblStatus.Text = "Enviando transacciones...";
            btnRun.Enabled = false;

            try
            {
                await RunDataTransfer(dtpStartDate.Value);
                lblStatus.Text = "Proceso Finalizado...";
            }
            catch (Exception ex)
            {
                lblStatus.Text = $"Error - {ex.Message}";
            }
            finally
            {
                isRunning = false;
                btnRun.Enabled = true;
            }
        }

        public async Task RunDataTransfer(DateTime startDate)
        {
            using var sourceConn = new SqlConnection(config.SourceConnectionString);
            using var destConn = new SqlConnection(config.DestinationConnectionString);

            await sourceConn.OpenAsync();
            await destConn.OpenAsync();

            var tableMappings = config.TableMappings.ToDictionary(t => t.SourceTable, t => t, StringComparer.OrdinalIgnoreCase);

            if (string.IsNullOrEmpty(config.TransactionTable) || !tableMappings.TryGetValue(config.TransactionTable, out var transactionsTable))
                throw new Exception("No se encontr� el mapeo de la tabla de transacciones");

            var transactions = await GetTransactions(sourceConn, startDate, transactionsTable);
            int total = transactions.Rows.Count;
            lblStatus.Text += $"\r\nTotal de Ordernes: {total}\r\n";
            int count = 0;
            foreach (DataRow transaction in transactions.Rows)
            {
                count++;
                var keyValues = GetKeyValues(transaction, transactionsTable.WhereMappings);

                using var destTrans = destConn.BeginTransaction();

                try
                {
                    var headerId = await InsertHeader(destConn, destTrans, transaction, transactionsTable);

                    lblcounter.Text = $"{count}/{total}";
                    foreach (var mapping in tableMappings.Values.Where(m => m.SourceTable != transactionsTable.SourceTable))
                    {
                        var where = mapping.WhereMappings?.FirstOrDefault(w => keyValues.ContainsKey(w.SourceKey));
                        if (where == null) continue;

                        var key = keyValues[where.SourceKey];
                        if (string.IsNullOrEmpty(key)) continue;

                        var records = await GetRelatedRecord(sourceConn, key, mapping);
                        if (records == null) continue;

                       
                        if (mapping.DestinationTable.Equals("Lines", StringComparison.OrdinalIgnoreCase))
                        {
                            foreach (DataRow record in records)
                            {
                                var headerMapping = mapping.ColumnMappings.FirstOrDefault(c => c.DestinationColumn == "HeaderId");
                                if (headerMapping != null)
                                    record[headerMapping.SourceColumn] = headerId;
                            }
                        }

                        await InsertRecord(destConn, destTrans, records, mapping);
                    }

                    destTrans.Commit();
                }
                catch
                {
                    destTrans.Rollback();
                    throw;
                }
            }
        }

        private Dictionary<string, string> GetKeyValues(DataRow row, List<WhereMapping> whereMappings)
        {
            var result = new Dictionary<string, string>();

            foreach (var mapping in whereMappings ?? new())
            {
                if (!row.Table.Columns.Contains(mapping.SourceKey)) continue;

                var value = row[mapping.SourceKey]?.ToString();
                result[mapping.SourceKey] = value;

                if (mapping.SourceKey == "CUSTACCOUNT")
                    result["ACCOUNTNUM"] = value;

                if (mapping.SourceKey == "STORE")
                    result["STOREID"] = value;
            }

            return result;
        }

        private async Task<DataTable> GetTransactions(SqlConnection conn, DateTime startDate, TableMapping table)
        {
            var columns = string.Join(", ", table.ColumnMappings.Select(c => c.SourceColumn));
            var date = table.WhereMappings?.FirstOrDefault(w => w.DestinationKey == "CreatedDate");
            var receipt = table.WhereMappings?.FirstOrDefault(w => w.DestinationKey == "ReceiptId");
            var payment = table.WhereMappings?.FirstOrDefault(w => w.DestinationKey == "Payment");

            if (date == null || receipt == null || payment == null)
                throw new Exception("No se encontr� el mapeo de fecha, recibo o pago");

            var dt = new DataTable();
            var query = $"SELECT {columns} FROM {table.SourceTable} WHERE {date.SourceKey} >= @date AND {receipt.SourceKey} != '' AND {payment.SourceKey} >= 0";

            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@date", startDate);

            using var adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dt);
            return dt;
        }

        private async Task<DataRowCollection> GetRelatedRecord(SqlConnection conn, string key, TableMapping table)
        {
            var where = table.WhereMappings?.FirstOrDefault();
            if (where == null) return null;

            var baseColumns = table.ColumnMappings.Select(c => $"{table.SourceTable}.{c.SourceColumn}").ToList();
            var joins = new List<string>();
            var allColumns = new List<string>(baseColumns);

            if (table.JoinTables?.Any() == true)
            {
                foreach (var jt in table.JoinTables)
                {
                    var joinCols = jt.ColumnMappings.Select(c => $"{jt.SourceTable}.{c.SourceColumn}");
                    allColumns.AddRange(joinCols);
                    joins.Add($"LEFT JOIN {jt.SourceTable} ON {table.SourceTable}.{jt.JoinCondition.SourceKey} = {jt.SourceTable}.{jt.JoinCondition.TargetKey}");
                }
            }

            var query = $"SELECT {string.Join(", ", allColumns)} FROM {table.SourceTable} {string.Join(" ", joins)} WHERE {table.SourceTable}.{where.SourceKey} = @key";

            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@key", key);

            var dt = new DataTable();
            using var adapter = new SqlDataAdapter(cmd);
            adapter.Fill(dt);

            return dt.Rows.Count > 0 ? dt.Rows : null;
        }

        private async Task<int> InsertHeader(SqlConnection conn, SqlTransaction trans, DataRow row, TableMapping table)
        {
            var where = table.WhereMappings?.FirstOrDefault(w => w.DestinationKey == "ReceiptId");

            if (where != null)
            {
                var sourceCol = table.ColumnMappings.FirstOrDefault(c => c.DestinationColumn == where.DestinationKey)?.SourceColumn;
                if (sourceCol != null && row[sourceCol] is not DBNull)
                {
                    var checkQuery = $"SELECT Id FROM {table.DestinationTable} WHERE {where.DestinationKey} = @key";
                    using var checkCmd = new SqlCommand(checkQuery, conn, trans);
                    checkCmd.Parameters.AddWithValue("@key", row[sourceCol]);
                    var result = await checkCmd.ExecuteScalarAsync();
                    if (result != null)
                        return (int)result;
                }
            }

            var columns = table.ColumnMappings.Select(c => c.DestinationColumn).ToList();
            var values = columns.Select(c => "@" + c).ToList();
            var query = $"INSERT INTO {table.DestinationTable} ({string.Join(", ", columns)}) OUTPUT INSERTED.Id VALUES ({string.Join(", ", values)})";

            using var cmd = new SqlCommand(query, conn, trans);
            foreach (var mapping in table.ColumnMappings)
                cmd.Parameters.AddWithValue("@" + mapping.DestinationColumn, row[mapping.SourceColumn] ?? DBNull.Value);

            return (int)await cmd.ExecuteScalarAsync();
        }

        private async Task InsertRecord(SqlConnection conn, SqlTransaction trans, DataRowCollection rows, TableMapping table)
        {
            foreach (DataRow row in rows)
            {
                var whereMappings = table.WhereMappings;
                if (whereMappings != null && whereMappings.Count > 0)
                {
                    var conditions = new List<string>();
                    var parameters = new List<SqlParameter>();

                    foreach (var where in whereMappings)
                    {
                        var sourceColumn = table.ColumnMappings
                            .FirstOrDefault(c => c.DestinationColumn == where.DestinationKey)?.SourceColumn;

                        if (!string.IsNullOrEmpty(sourceColumn) && row[sourceColumn] is not DBNull)
                        {
                            var paramName = $"@{where.DestinationKey}";
                            conditions.Add($"{where.DestinationKey} = {paramName}");
                            parameters.Add(new SqlParameter(paramName, row[sourceColumn]));
                        }
                    }

                    if (conditions.Count > 0)
                    {
                        var whereClause = string.Join(" AND ", conditions);
                        var checkQuery = $"SELECT COUNT(1) FROM {table.DestinationTable} WHERE {whereClause}";
                        using var checkCmd = new SqlCommand(checkQuery, conn, trans);
                        checkCmd.Parameters.AddRange(parameters.ToArray());

                        var exists = (int)await checkCmd.ExecuteScalarAsync();
                        if (exists > 0) return;
                    }
                }


                // Construcci�n de columnas y valores
                var columns = new List<string>();
                var mappings = new List<ColumnMapping>();

                columns.AddRange(table.ColumnMappings.Select(c => c.DestinationColumn));
                mappings.AddRange(table.ColumnMappings);

                if (table.JoinTables?.Any() == true)
                {
                    var joinTable = table.JoinTables.First();
                    columns.AddRange(joinTable.ColumnMappings.Select(c => c.DestinationColumn));
                    mappings.AddRange(joinTable.ColumnMappings);
                }

                var values = columns.Select(col => "@" + col);
                var insertQuery = $"INSERT INTO {table.DestinationTable} ({string.Join(", ", columns)}) VALUES ({string.Join(", ", values)})";



                using var insertCmd = new SqlCommand(insertQuery, conn, trans);
                bool save = true;
                foreach (var map in mappings)
                {
                    var paramName = "@" + map.DestinationColumn;
                    var paramValue = row[map.SourceColumn] ?? DBNull.Value;
                    Debug.Print(map.DestinationColumn + " -> " + paramValue.ToString());
                    if (config.LinesTable == table.DestinationTable)
                    {
                        if (config.CanBeDispatched == map.DestinationColumn)
                        {
                            try
                            {
                                if (!Convert.ToBoolean(row[map.SourceColumn]))
                                    save = false;
                                else
                                {
                                    var updateQuery = $"UPDATE  {config.HeaderTable} SET STATUS = 4 WHERE ID = {row[config.HeaderId]} AND STATUS = 5;";
                                    using var updateCmd = new SqlCommand(updateQuery, conn, trans);
                                    await updateCmd.ExecuteNonQueryAsync();
                                }
                            }
                            catch (Exception) {
                                save = false;
                            }

                        }
                        if (config.Quantity == map.DestinationColumn)
                            paramValue = Math.Abs(Convert.ToInt32(row[map.SourceColumn])).ToString() ?? "1";

                    }
                    insertCmd.Parameters.AddWithValue(paramName, paramValue);
                }
                if(save)
                    await insertCmd.ExecuteNonQueryAsync();
            }
        }

        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length > 0)
                if (Int32.TryParse(args[0], out int number))
                    new DataTransferApp().RunDataTransfer(DateTime.Now.AddMinutes(Math.Abs(number) * -1)).GetAwaiter().GetResult();
                else
                    new DataTransferApp().RunDataTransfer(DateTime.Now.AddMinutes(-30)).GetAwaiter().GetResult();
            else
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new DataTransferApp());
                }
        }
    }
}
